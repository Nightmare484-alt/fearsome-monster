package com.maya.assistant

import com.maya.assistant.actions.ActionExecutor
import com.maya.assistant.actions.ActionResult
import com.maya.assistant.actions.AppEntry
import com.maya.assistant.actions.LocalCommand
import com.maya.assistant.ai.ChatClient
import com.maya.assistant.ai.ChatError
import com.maya.assistant.ai.ChatException
import com.maya.assistant.ai.ChatRequest
import com.maya.assistant.capture.CaptureFailure
import com.maya.assistant.capture.CaptureResult
import com.maya.assistant.data.ApiKeyStore
import com.maya.assistant.data.MayaSettings
import com.maya.assistant.data.MemoryNote
import com.maya.assistant.data.MemoryStore
import com.maya.assistant.data.SettingsStore
import com.maya.assistant.vm.MayaViewModel
import com.maya.assistant.vm.Phase
import com.maya.assistant.vm.UiError
import com.maya.assistant.voice.Speaker
import com.maya.assistant.voice.SpeechError
import com.maya.assistant.voice.SpeechInput
import com.maya.assistant.voice.SpeechListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

private class FakeChat(var reply: String = "Hi there", var failWith: ChatError? = null) : ChatClient {
    val requests = mutableListOf<ChatRequest>()
    var models = listOf(com.maya.assistant.ai.ModelInfo("gemini-a", "A"))
    override suspend fun listModels(apiKey: String): List<com.maya.assistant.ai.ModelInfo> {
        failWith?.let { throw ChatException(it) }
        return models
    }
    override suspend fun send(request: ChatRequest): String {
        requests += request
        failWith?.let { throw ChatException(it) }
        return reply
    }
}

private class FakeKeys(var key: String = "sk-test") : ApiKeyStore {
    override fun get() = key
    override fun set(key: String) { this.key = key.trim() }
    override fun clear() { key = "" }
}

private class FakeSettings : SettingsStore {
    override var settings = MayaSettings(userName = "Sam", speakReplies = true)
    override var micPermissionAsked = false
    override fun clear() { settings = MayaSettings(); micPermissionAsked = false }
}

private class FakeMemory : MemoryStore {
    private val notes = mutableListOf<MemoryNote>()
    override fun all() = notes.toList()
    override fun add(text: String): MemoryNote? =
        if (text.isBlank()) null else MemoryNote(notes.size + 1L, text.trim(), 0).also { notes += it }
    override fun remove(id: Long) { notes.removeAll { it.id == id } }
    override fun clear() = notes.clear()
}

private class FakeSpeech(var isAvailable: Boolean = true) : SpeechInput {
    override val available get() = isAvailable
    var listener: SpeechListener? = null
    var stopped = false
    override fun start(listener: SpeechListener) { this.listener = listener }
    override fun stop() { stopped = true }
    override fun cancel() {}
    override fun release() {}
}

private class FakeSpeaker : Speaker {
    val spoken = mutableListOf<String>()
    var onDone: (() -> Unit)? = null
    override fun speak(text: String, onDone: () -> Unit) { spoken += text; this.onDone = onDone }
    override fun stop() {}
    override fun release() {}
}

private class FakeActions(var result: ActionResult = ActionResult.Done("Opening X.")) : ActionExecutor {
    val executed = mutableListOf<LocalCommand>()
    override fun execute(command: LocalCommand): ActionResult { executed += command; return result }
    override fun launchableApps() = listOf(AppEntry("X", "x"))
    override fun launch(packageName: String) = packageName == "x"
}

@OptIn(ExperimentalCoroutinesApi::class)
class MayaViewModelTest {
    private lateinit var chat: FakeChat
    private lateinit var keys: FakeKeys
    private lateinit var settings: FakeSettings
    private lateinit var memory: FakeMemory
    private lateinit var speech: FakeSpeech
    private lateinit var speaker: FakeSpeaker
    private lateinit var actions: FakeActions
    private lateinit var captures: MutableSharedFlow<CaptureResult>

    @Before fun setUp() {
        Dispatchers.setMain(UnconfinedTestDispatcher())
        chat = FakeChat(); keys = FakeKeys(); settings = FakeSettings(); memory = FakeMemory()
        speech = FakeSpeech(); speaker = FakeSpeaker(); actions = FakeActions()
        captures = MutableSharedFlow(extraBufferCapacity = 1)
    }

    @After fun tearDown() = Dispatchers.resetMain()

    private fun vm() = MayaViewModel(chat, keys, settings, memory, speech, speaker, actions, captures)

    @Test fun missingKeyShowsErrorAndNeverCallsTheNetwork() {
        keys.key = ""
        val vm = vm()
        vm.submitText("hello")
        assertEquals(Phase.ERROR, vm.state.value.phase)
        assertEquals(UiError.MISSING_KEY, vm.state.value.error)
        assertTrue(chat.requests.isEmpty())
    }

    @Test fun successfulReplyIsShownSpokenAndRemembered() {
        val vm = vm()
        vm.submitText("hello")
        assertEquals("Hi there", vm.state.value.reply)
        assertEquals(Phase.SPEAKING, vm.state.value.phase)
        assertEquals(listOf("Hi there"), speaker.spoken)
        speaker.onDone!!.invoke()
        assertEquals(Phase.IDLE, vm.state.value.phase)

        vm.submitText("and again")
        assertEquals(2, chat.requests[1].history.size) // first turn carried into the second request
    }

    @Test fun repliesAreNotSpokenWhenDisabled() {
        settings.settings = settings.settings.copy(speakReplies = false)
        val vm = vm()
        vm.submitText("hello")
        assertEquals(Phase.IDLE, vm.state.value.phase)
        assertTrue(speaker.spoken.isEmpty())
    }

    @Test fun networkAndAuthErrorsMapToUiErrors() {
        val vm = vm()
        chat.failWith = ChatError.NETWORK
        vm.submitText("hi")
        assertEquals(UiError.NETWORK, vm.state.value.error)

        chat.failWith = ChatError.UNAUTHORIZED
        vm.submitText("hi")
        assertEquals(UiError.UNAUTHORIZED, vm.state.value.error)
        assertEquals(false, vm.state.value.hasApiKey)
    }

    @Test fun failedRequestDoesNotPolluteHistory() {
        val vm = vm()
        chat.failWith = ChatError.SERVER
        vm.submitText("one")
        chat.failWith = null
        vm.submitText("two")
        assertTrue(chat.requests.last().history.isEmpty())
    }

    @Test fun rememberCommandSavesNoteWithoutCallingAi() {
        val vm = vm()
        vm.submitText("remember that I like tea")
        assertEquals(listOf("I like tea"), vm.state.value.notes.map { it.text })
        assertTrue(chat.requests.isEmpty())
    }

    @Test fun memoryNotesReachTheSystemPromptAndCanBeDeleted() {
        val vm = vm()
        vm.addNote("prefers metric units")
        vm.submitText("how tall is Everest?")
        assertTrue(chat.requests.single().system.contains("prefers metric units"))
        vm.removeNote(vm.state.value.notes.single().id)
        assertTrue(vm.state.value.notes.isEmpty())
    }

    @Test fun localCommandIsHandledWithoutAiAndNeedsNoKey() {
        keys.key = ""
        val vm = vm()
        vm.submitText("open X")
        assertEquals(listOf<LocalCommand>(LocalCommand.OpenApp("X")), actions.executed)
        assertEquals("Opening X.", vm.state.value.reply)
        assertNull(vm.state.value.error)
    }

    @Test fun unknownAppFallsBackToTheAi() {
        actions.result = ActionResult.NotHandled
        val vm = vm()
        vm.submitText("open the door")
        assertEquals(1, chat.requests.size)
    }

    @Test fun listeningDeliversTranscriptToAi() {
        val vm = vm()
        vm.startListening()
        assertEquals(Phase.LISTENING, vm.state.value.phase)
        speech.listener!!.onPartial("what is")
        assertEquals("what is", vm.state.value.partial)
        speech.listener!!.onResult("what is the time")
        assertEquals("what is the time", chat.requests.single().userText)
    }

    @Test fun speechErrorsBecomeFriendlyErrors() {
        val vm = vm()
        vm.startListening()
        speech.listener!!.onError(SpeechError.NO_MATCH)
        assertEquals(UiError.SPEECH_NO_MATCH, vm.state.value.error)

        speech.isAvailable = false
        vm.startListening()
        assertEquals(UiError.SPEECH_UNAVAILABLE, vm.state.value.error)
    }

    @Test fun tappingMicWhileListeningStopsRecognition() {
        val vm = vm()
        vm.startListening()
        vm.startListening()
        assertTrue(speech.stopped)
    }

    @Test fun micDenialMessagesDistinguishBlockedFromDenied() {
        val vm = vm()
        vm.micPermissionDenied(blocked = false)
        assertEquals(UiError.MIC_DENIED, vm.state.value.error)
        vm.micPermissionDenied(blocked = true)
        assertEquals(UiError.MIC_BLOCKED, vm.state.value.error)
    }

    @Test fun screenCaptureSuccessSendsImageToAi() {
        val vm = vm()
        vm.screenCaptureStarting()
        captures.tryEmit(CaptureResult.Success(byteArrayOf(9, 9)))
        val req = chat.requests.single()
        assertTrue(req.image!!.contentEquals(byteArrayOf(9, 9)))
        assertEquals(MayaViewModel.SCREEN_PROMPT, req.userText)
    }

    @Test fun screenCaptureFailureAndDenialShowErrors() {
        val vm = vm()
        captures.tryEmit(CaptureResult.Failure(CaptureFailure.DENIED))
        assertEquals(UiError.CAPTURE_DENIED, vm.state.value.error)
        captures.tryEmit(CaptureResult.Failure(CaptureFailure.NO_FRAME))
        assertEquals(UiError.CAPTURE_FAILED, vm.state.value.error)
        vm.screenCaptureDenied()
        assertEquals(UiError.CAPTURE_DENIED, vm.state.value.error)
    }

    @Test fun deleteAllDataWipesKeyMemoryAndConversation() {
        val vm = vm()
        vm.addNote("secret")
        vm.submitText("hello")
        vm.deleteAllData()
        assertEquals("", keys.key)
        assertTrue(memory.all().isEmpty())
        assertEquals("", vm.state.value.reply)
        assertEquals(false, vm.state.value.hasApiKey)
    }

    @Test fun savingAndClearingKeyUpdatesState() {
        keys.key = ""
        val vm = vm()
        vm.saveApiKey("  sk-new ")
        assertEquals("sk-new", keys.key)
        assertTrue(vm.state.value.hasApiKey)
        vm.clearApiKey()
        assertEquals(false, vm.state.value.hasApiKey)
    }

    @Test fun refreshModelsLoadsListAndMarksConnected() {
        val vm = vm()
        vm.refreshModels()
        assertEquals(listOf("gemini-a"), vm.state.value.models.map { it.id })
        assertTrue(vm.state.value.connection.ok != null)
    }

    @Test fun refreshModelsWithoutKeyOrWithBadKeyReportsError() {
        keys.key = ""
        val vm = vm()
        vm.refreshModels()
        assertEquals(UiError.MISSING_KEY, vm.state.value.connection.error)
        keys.key = "bad"
        chat.failWith = ChatError.UNAUTHORIZED
        vm.refreshModels()
        assertEquals(UiError.UNAUTHORIZED, vm.state.value.connection.error)
        assertEquals(false, vm.state.value.hasApiKey)
    }

    @Test fun chatUsesSelectedModelAndTestDoesNotChangeIt() {
        settings.settings = settings.settings.copy(model = "gemini-custom")
        val vm = vm()
        vm.submitText("hello")
        assertEquals("gemini-custom", chat.requests.last().model)
        vm.testSelectedModel()
        assertEquals("gemini-custom", settings.settings.model)
        assertEquals("gemini-custom", chat.requests.last().model)
        assertTrue(vm.state.value.modelCheck.ok != null)
    }
}
