package com.maya.assistant.actions

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock

data class AppEntry(val label: String, val packageName: String)

sealed interface ActionResult {
    data class Done(val message: String) : ActionResult
    data class Failed(val message: String) : ActionResult
    /** The executor could not act (e.g. no such app); the caller may fall back to the AI. */
    data object NotHandled : ActionResult
}

interface ActionExecutor {
    fun execute(command: LocalCommand): ActionResult
    fun launchableApps(): List<AppEntry>
    fun launch(packageName: String): Boolean
}

object AppMatcher {
    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** Exact name beats prefix beats substring; shorter labels win ties. */
    fun best(query: String, apps: List<AppEntry>): AppEntry? {
        val q = norm(query)
        if (q.isEmpty()) return null
        apps.firstOrNull { norm(it.label) == q }?.let { return it }
        apps.filter { norm(it.label).startsWith(q) }.minByOrNull { it.label.length }?.let { return it }
        return apps.filter { norm(it.label).contains(q) }.minByOrNull { it.label.length }
    }
}

class AndroidActionExecutor(private val context: Context) : ActionExecutor {

    override fun launchableApps(): List<AppEntry> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = if (android.os.Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION") pm.queryIntentActivities(intent, 0)
        }
        return infos
            .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.packageName != context.packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    override fun launch(packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        return start(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun execute(command: LocalCommand): ActionResult = when (command) {
        is LocalCommand.OpenApp -> {
            val app = AppMatcher.best(command.name, launchableApps())
            when {
                app == null -> ActionResult.NotHandled
                launch(app.packageName) -> ActionResult.Done("Opening ${app.label}.")
                else -> ActionResult.Failed("I couldn't open ${app.label}.")
            }
        }
        is LocalCommand.YouTube -> view(
            "https://www.youtube.com/results?search_query=" + Uri.encode(command.query),
            "Searching YouTube for ${command.query}.",
        )
        is LocalCommand.WebSearch -> view(
            "https://www.google.com/search?q=" + Uri.encode(command.query),
            "Searching the web for ${command.query}.",
        )
        is LocalCommand.Timer -> {
            // Hands off to the Clock app; no SET_ALARM permission needed because we don't skip its UI.
            val intent = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, command.seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Maya timer")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (start(intent)) ActionResult.Done("Setting a timer in your Clock app.")
            else ActionResult.Failed("I couldn't find a Clock app to set the timer.")
        }
        is LocalCommand.Remember -> ActionResult.NotHandled // handled by the ViewModel
    }

    private fun view(url: String, doneMessage: String): ActionResult {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (start(intent)) ActionResult.Done(doneMessage)
        else ActionResult.Failed("I couldn't find an app to open that.")
    }

    private fun start(intent: Intent): Boolean = try {
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }
}
