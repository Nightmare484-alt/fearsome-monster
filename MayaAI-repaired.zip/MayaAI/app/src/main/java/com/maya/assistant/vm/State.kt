package com.maya.assistant.vm

import com.maya.assistant.ai.ModelInfo
import com.maya.assistant.data.MayaSettings
import com.maya.assistant.data.MemoryNote

enum class MicAction { START, REQUEST, SHOW_RATIONALE, OPEN_SETTINGS }

/**
 * What to do when the user taps Tap to Talk.
 * - granted                          -> start listening
 * - never asked                      -> ask
 * - denied once (system says explain) -> show our own rationale, then ask
 * - denied and system won't ask again -> send the user to app settings
 */
fun decideMicAction(granted: Boolean, shouldShowRationale: Boolean, askedBefore: Boolean): MicAction = when {
    granted -> MicAction.START
    shouldShowRationale -> MicAction.SHOW_RATIONALE
    askedBefore -> MicAction.OPEN_SETTINGS
    else -> MicAction.REQUEST
}

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

enum class UiError {
    MISSING_KEY, UNAUTHORIZED, RATE_LIMITED, OVERLOADED, BAD_REQUEST, SERVER, NETWORK, TIMEOUT, BAD_RESPONSE, UNKNOWN,
    MIC_DENIED, MIC_BLOCKED, SPEECH_UNAVAILABLE, SPEECH_NO_MATCH, SPEECH_NETWORK, SPEECH_BUSY, SPEECH_OTHER,
    CAPTURE_DENIED, CAPTURE_FAILED, NO_CAMERA_APP, PHOTO_FAILED, FILE_FAILED, APP_FAILED,
}

/** Result of a connection or model test. Idle when neither running nor finished. */
data class Check(val running: Boolean = false, val ok: String? = null, val error: UiError? = null)

data class UiState(
    val phase: Phase = Phase.IDLE,
    val partial: String = "",
    val reply: String = "",
    val error: UiError? = null,
    /** Specific, accurate explanation for [error] (e.g. how long Google asked us to wait). */
    val errorDetail: String? = null,
    val status: String? = null,
    val settings: MayaSettings = MayaSettings(),
    val notes: List<MemoryNote> = emptyList(),
    val hasApiKey: Boolean = false,
    val models: List<ModelInfo> = emptyList(),
    val connection: Check = Check(),
    val modelCheck: Check = Check(),
    val inForeground: Boolean = true,
) {
    val backgroundActive: Boolean get() = !inForeground && (phase == Phase.THINKING || phase == Phase.SPEAKING)
}
