package com.maya.assistant.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import com.maya.assistant.data.ApiKeyStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64
import kotlin.math.sqrt

/**
 * Natural voice via Gemini TTS, reusing the existing Gemini API key. Falls back to the system
 * [fallback] speaker if there is no key, the request fails (quota, network, model change), or
 * nothing could be played before the failure.
 */
class GeminiSpeaker(
    private val keys: ApiKeyStore,
    private val fallback: Speaker,
    private val model: String = DEFAULT_MODEL,
    private val voice: String = DEFAULT_VOICE,
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta",
) : Speaker {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile private var blockedUntil = 0L
    private val _level = MutableStateFlow(0f)
    override val level: StateFlow<Float> = _level.asStateFlow()
    private var levelJob: Job? = null

    /** System voice, with its word-boundary level forwarded so lip sync still works. */
    private fun speakFallback(text: String, onDone: () -> Unit) {
        levelJob?.cancel()
        levelJob = scope.launch { fallback.level.collect { _level.value = it } }
        fallback.speak(text, onDone)
    }

    override fun speak(text: String, onDone: () -> Unit) {
        stop()
        val key = keys.get()
        // The free tier allows only a few TTS requests per minute. Use Gemini TTS for ONE request per reply (short
        // replies, which is what the system prompt asks for) and the system voice for long text or during a cooldown.
        if (key.isBlank() || text.isBlank() || text.length > MAX_CHUNK || System.currentTimeMillis() < blockedUntil) {
            return speakFallback(text, onDone)
        }
        job = scope.launch {
            var played = false
            var next: kotlinx.coroutines.Deferred<ByteArray>? = null
            try {
                val chunks = chunk(text)
                // Prefetch: synthesize chunk N+1 while chunk N plays.
                next = scope.async { synth(key, chunks[0]) }
                for (i in chunks.indices) {
                    val pcm = next!!.await()
                    if (i + 1 < chunks.size) next = scope.async { synth(key, chunks[i + 1]) }
                    play(pcm)
                    played = true
                }
                main.post(onDone)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                // Never leave the UI stuck in SPEAKING.
                if (played) main.post(onDone) else main.post { fallback.speak(text, onDone) }
            } finally {
                next?.cancel()
            }
        }
    }

    private fun synth(key: String, text: String): ByteArray {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject()
                .put("text", "Say warmly and naturally, like a friendly person talking: $text")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject()
                    .put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
            .toString()
        val conn = URL("$baseUrl/models/$model:generateContent").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 45_000
            conn.doOutput = true
            conn.setRequestProperty("x-goog-api-key", key)
            conn.setRequestProperty("content-type", "application/json")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val resp = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code == 429) {
                val info = com.maya.assistant.ai.GeminiClient.parseError(resp, conn.getHeaderField("Retry-After"))
                blockedUntil = System.currentTimeMillis() + (info.retryAfterSec ?: 60) * 1000L
            }
            if (code !in 200..299) error("tts http $code")
            return parsePcm(resp)
        } finally {
            conn.disconnect()
        }
    }

    private suspend fun play(pcm: ByteArray) = withContext(Dispatchers.IO) {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(pcm.size)
            .build()
        track = t
        try {
            t.write(pcm, 0, pcm.size)
            t.play()
            val frames = pcm.size / 2
            val env = envelope(pcm)
            val deadline = System.currentTimeMillis() + frames * 1000L / SAMPLE_RATE + 2_000
            while (isActive && t.playbackHeadPosition < frames && System.currentTimeMillis() < deadline) {
                // Mouth follows the loudness of what is actually being played; no extra API calls.
                _level.value = env.getOrElse(t.playbackHeadPosition / ENV_WINDOW) { 0f }
                delay(40)
            }
        } finally {
            _level.value = 0f
            track = null
            try { t.stop() } catch (_: IllegalStateException) {}
            t.release()
        }
    }

    override fun stop() {
        job?.cancel()
        job = null
        levelJob?.cancel()
        levelJob = null
        _level.value = 0f
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        fallback.stop()
    }

    override fun release() {
        stop()
        scope.cancel()
        fallback.release()
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash-preview-tts"
        const val DEFAULT_VOICE = "Aoede"
        const val SAMPLE_RATE = 24_000
        private const val MAX_CHUNK = 700
        /** One loudness sample per 40 ms of audio. */
        const val ENV_WINDOW = SAMPLE_RATE / 25

        /** Loudness (RMS) per [ENV_WINDOW] samples of 16-bit little-endian PCM, normalised to 0..1 with a noise floor. */
        fun envelope(pcm: ByteArray, window: Int = ENV_WINDOW): FloatArray {
            val n = pcm.size / 2
            val rms = FloatArray((n + window - 1) / window)
            for (w in rms.indices) {
                val from = w * window
                val to = minOf(n, from + window)
                var sum = 0.0
                for (i in from until to) {
                    val v = (pcm[2 * i + 1].toInt() shl 8) or (pcm[2 * i].toInt() and 0xFF)
                    sum += v.toDouble() * v
                }
                rms[w] = if (to > from) (sqrt(sum / (to - from)) / 32768.0).toFloat() else 0f
            }
            val peak = rms.maxOrNull() ?: 0f
            if (peak <= 0f) return rms
            return FloatArray(rms.size) { val x = rms[it] / peak; if (x < 0.1f) 0f else x }
        }

        /** Splits on sentence boundaries into chunks small enough for fast TTS responses. */
        fun chunk(text: String): List<String> {
            val out = mutableListOf<String>()
            val cur = StringBuilder()
            for (s in text.split(Regex("(?<=[.!?])\\s+"))) {
                if (cur.isNotEmpty() && cur.length + s.length > MAX_CHUNK) { out += cur.toString(); cur.clear() }
                var part = s
                while (part.length > MAX_CHUNK) { out += part.take(MAX_CHUNK); part = part.drop(MAX_CHUNK) }
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(part)
            }
            if (cur.isNotBlank()) out += cur.toString()
            return out.ifEmpty { listOf(text) }
        }

        /** Extracts base64 16-bit PCM (24 kHz mono) from a generateContent response. */
        fun parsePcm(json: String): ByteArray {
            val parts = JSONObject(json).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            for (i in 0 until parts.length()) {
                val data = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data").orEmpty()
                if (data.isNotEmpty()) return Base64.getDecoder().decode(data)
            }
            error("no audio in response")
        }
    }
}
