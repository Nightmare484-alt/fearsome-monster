#!/data/data/com.termux/files/usr/bin/bash
# One-time setup for building Maya AI inside Termux (aarch64). Needs ~2.5 GB free storage and Wi-Fi.
set -euo pipefail

GRADLE_VERSION=8.10.2
SDK="$HOME/android-sdk"

pkg update -y
pkg install -y openjdk-17 aapt2 wget unzip git

# Gradle (pure Java, works on Termux). AGP 8.7 needs Gradle 8.9+; 8.10.2 is known-compatible.
if [ ! -d "$HOME/gradle-$GRADLE_VERSION" ]; then
  wget -q --show-progress "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -O "$HOME/gradle.zip"
  unzip -q "$HOME/gradle.zip" -d "$HOME" && rm "$HOME/gradle.zip"
fi

# Android SDK: only the platform jar (android-34) is needed. aapt2 comes from the Termux package,
# D8/R8/signing come from Gradle's Maven dependencies, so no native build-tools are required.
export JAVA_HOME="$PREFIX/lib/jvm/java-17-openjdk"
if [ ! -d "$SDK/cmdline-tools/latest" ]; then
  mkdir -p "$SDK/cmdline-tools"
  wget -q --show-progress "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" -O "$HOME/cmdtools.zip"
  unzip -q "$HOME/cmdtools.zip" -d "$SDK/cmdline-tools" && mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest"
  rm "$HOME/cmdtools.zip"
fi
yes | "$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" --licenses >/dev/null || true
"$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" "platforms;android-34"

echo "Setup finished. Next: ./scripts/build-termux.sh"
